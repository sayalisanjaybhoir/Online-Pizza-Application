import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, ActivatedRouteSnapshot, Router } from '@angular/router';
import { PizzaOrder } from '../model/pizzaorder.model';


import { PizzaOrderService } from '../service/pizzaorder.service';


@Component({
 
  selector: 'update-order',
  template: `
             <div class="col-md-5">
            <div class="container md-8">
            <br>
            <div style="card-align: center;">
            <div class="card" style="width: 45rem;">
            <div class="card-body">
  
  <form [formGroup]="updateForm" autocomplete = "off" novalidate (ngSubmit)="updatePizzaOrder(updateForm.value)">
 
  <div class="form-row">
      <div class="form-group col-md-6">
          <label for="inputOrderId">BookingOrderId</label>
          <em *ngIf="updateForm.controls.bookingOrderId?.invalid && (updateForm.controls.bookingOrderId?.touched)">Required</em> 
          <input id="inputOrderId" type="number" readonly class="form-control" formControlName="bookingOrderId"  readonly name = "bookingOrderId" placeholder="enter id" readonly />
      </div> 

            <div class="form-group col-md-6">
            <em *ngIf="updateForm.controls.bookingOrderId?.invalid && (updateForm.controls.bookingOrderId?.touched)">Enter date</em> 

          <label for="inputorderDate">Date</label>
          <input id="inputorderDate" type="date"  min="{{minDate}}" max="{{maxDate}}" class="form-control" formControlName ="orderDate" required name = "orderDate"  placeholder="Enter date">

     </div>
  </div>
  <div class="form-row">
            <div class="form-group col-md-6">
            <label for="inputTransactionMode">transactionMode</label>
            <select id ="inputTransactionMode" formControlName="inputTransactionMode" class="form-control">
            <option *ngFor="let transc of tracnsaction">{{transc}}</option>
            </select>
            </div>
       <div class="form-group col-md-6">
      <label for="inputQuantity">Quantity</label>
      <em *ngIf="updateForm.controls.quantity?.invalid && (updateForm.controls.quantity?.touched)">Required</em> 
      <em *ngIf ="updateForm.get('quantity').touched && updateForm.get('quantity').hasError('min')"> Enter quantity greater than 1</em> 

      <input id="inputQuantity" type="number" class="form-control" formControlName="quantity"  required name = "quantity"  placeholder="enter the no of quantity">
      </div>
  </div>
   <div class="form-row">
      <div class="form-group col-md-6">
          <label for="inputSize">Size</label>
          <em *ngIf="updateForm.controls.size?.invalid && (updateForm.controls.size?.touched)">Required</em> 
          <select id ="inputSize" formControlName="size" class="form-control">
          <option *ngFor="let psize of pizzasize">{{psize}}</option>
         </select>
          </div>
  </div>
  <div formGroupName="order">
  <div class="form-row" >
      <div class="form-group col-md-6">
          <label for="inputorderType">orderType</label>
          <em *ngIf="updateForm.controls.orderType?.invalid && (updateForm.controls.orderType?.touched)">Required</em> 
          <input id="inputorderType" type="text" class="form-control" formControlName="orderType"  required name = "orderType"  placeholder="enter order type">
      </div>
      <div class="form-group col-md-6">
      <label for="inputorderDescription">Order Description </label>
      <em *ngIf="updateForm.controls.orderDescription?.invalid && (updateForm.controls.orderDescription?.touched)">Required</em> 
      <em *ngIf ="updateForm.get('order.orderDescription').touched && updateForm.get('order.orderDescription').hasError('required')">description required</em>

      <input id="inputorderDescription" type="text" class="form-control" formControlName="orderDescription"  required name = "orderDescription"  placeholder="enter desc">
      </div>
      <!--
      <div class="form-group col-md-6">
      <label for="inputCustomerId">Customer Id</label>
      <em *ngIf="updateForm.controls.orderCustomerId?.invalid && (updateForm.controls.orderCustomerId?.touched)">Required</em> 
      <input  id="inputCustomerId"  type="number" class="form-control" required formControlName="orderCustomerId" name = "orderCustomerId"  placeholder="enter customer id">
      </div> -->
    </div>
  </div>
  <button type="submit"  [disabled]=updateForm.valid class="btn btn-primary">Update</button>

  </form>
            
            `,
            styleUrls: ['./bookpizzaorder.component.css']


})
export class UpdatePizzaOrderComponent implements OnInit
{
    pizzasize: any = ['small', 'medium', 'large']
    tracnsaction :any =['online','cash','wallet']
    minDate :any = "2021-06-18";

  pizza :PizzaOrder;
  updateForm: FormGroup;
  order :FormGroup;
  constructor(private router: Router, private pizzaService: PizzaOrderService, private activatedRoute: ActivatedRoute) 
  {

  }
    ngOnInit(): void {
        
        this.updateForm = new FormGroup 
        ({
             bookingOrderId : new FormControl(+this.activatedRoute.snapshot.params['pizzaId']),
            orderDate :new FormControl(null,Validators.required),
            transactionMode : new FormControl(null,Validators.required),
            quantity : new FormControl(null,[Validators.required,Validators.min(1)]),
            size : new FormControl(null),
            totalCost : new FormControl(null),
            order : new FormGroup
            ({
                 orderId: new FormControl(null),
                orderType: new FormControl(null),
                orderDescription: new FormControl(null,[Validators.required,Validators.minLength(4)]),
                orderCustomerId: new FormControl(null)
            })
        });
    }
    updatePizzaOrder(pizza :PizzaOrder)
    {
        this.pizzaService.updatePizza(this.activatedRoute.snapshot.params.pizzaId,this.updateForm.value).subscribe(pizzaList =>this.pizza =pizzaList);
        console.log("in update pizza")
        alert("Do you want to update the pizza")
        console.log("*********"+JSON.stringify(pizza))
        this.router.navigate(['/userpage/pizzaorder/all']);
    } 
}


