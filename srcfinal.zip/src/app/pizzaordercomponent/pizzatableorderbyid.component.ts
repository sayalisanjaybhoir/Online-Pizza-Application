import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PizzaOrder } from '../model/pizzaorder.model';
import { PizzaService } from '../service/pizza.service';

import { PizzaOrderService } from '../service/pizzaorder.service';


@Component({
    selector: 'table-pizza-id',
    template: ` <div>
                 {{pizzaOrders | json}}  
                 <table class="table">
                  <thead class="thead-dark">
                  <tr>
                    <th scope="col">BookingOrderId</th>
                    <th scope="col">Transaction Mode</th>
                    <th scope="col">Quantity</th>
                    <th scope="col">Size</th>
                    <th scope="col">Total Cost</th>
                    <th scope="col">Order Date</th>
                    <th scope="col">Order Id</th>
                    <th scope="col">Order Type</th>
                    <th scope="col">Order Description</th>
                    <th scope="col">Order Customer Id</th>
                    <th scope="col">Pizza Id</th>
                    <th scope="col">Pizza Name</th>
                    <th scope="col">Pizza Type </th>
                    <th scope="col"> Pizza Description </th>
                    <th scope="col">Pizza Cost </th>
                  </tr>
                    <div>BookingOrderId : {{pizzaOrders?.bookingOrderId}}</div>
                    <div>Transaction Mode : {{pizzaOrders?.transactionMode}}</div>
                    <div>Quantity : {{pizzaOrders?.quantity}}</div>
                    <div>Size : {{pizzaOrders?.size}}</div>
                    <div> 
                        Total Cost :{{pizzaOrders?.totalCost | currency: 'INR'}}
                    </div>
                    <div >Order Date : {{pizzaOrders?.orderDate | date}}
                    </div>
                    <div>
                    <div> Order Id :{{pizzaOrders?.order?.orderId}}</div>
                    <div> Order Type :{{pizzaOrders?.order?.orderType}}</div>
                    <div> Order Description :{{pizzaOrders?.order?.orderDescription}}</div>
                    <div> Order Customer Id :{{pizzaOrders?.order?.orderCustomerId}}</div>
                    </div>
                    <div *ngIf="pizzaOrders.pizzaSet">
                    <div *ngFor="let pizza of pizzaOrders.pizzaSet">
                    <div> Pizza Id :{{pizza?.pizzaId}}</div>
                    <div> Pizza Name:{{pizza?.pizzaName}}</div>
                    <div> Pizza Type :{{pizza?.pizzaType}}</div>
                    <div> Pizza Description :{{pizza?.pizzaDescription}}</div>
                     <div> Pizza Cost :{{pizza?.pizzaCost}}</div>
                     </div>
                     </div>
                    <button type="submit" class="btn btn-primary" (click) = "deletePizzaOrder(pizzaOrders?.bookingOrderId)">Delete</button>
                    <br/>
                   <button type="submit" class="btn btn-primary" (click) = "updatePizza(pizzaOrders?.bookingOrderId)">Update</button>
                  <button type="submit" class="btn btn-primary" (click) = "totalCostOfPizza(pizzaOrders?.bookingOrderId,pizzaOrders?.size,pizzaOrders?.quantity)">Calculate</button>    
                  </div> 
                </div>
                `,

})
export class PizzaTableOrderByIdComponent {

  
  pizzaOrders: PizzaOrder;
  resError: string;
  

   
  constructor(private pizzaOrderService: PizzaOrderService, private activatedRoute: ActivatedRoute,private router :Router,private pizzaService :PizzaService) 
    {
      console.log("pizzaid in component"+activatedRoute.snapshot.params['pizzaId'])
        // this.pizzaOrders = this.pizzaService.getPizzaById(+activatedRoute.snapshot.params['pizzaId']);
         this.pizzaOrderService.getPizzaById(+activatedRoute.snapshot.params['pizzaId']).subscribe(
                                                                                          ( p )=>{this.pizzaOrders = p});
                  

        

       
        }
    
        deletePizzaOrder(pizzaId : number){
          this.router.navigateByUrl("/userpage/pizzaorder/deleteorder/"+pizzaId)
        }

        updatePizza(pizzaId : number)
        {
          this.router.navigateByUrl("/userpage/pizzaorder/updatePizzaOrder/"+pizzaId)
        }

        totalCostOfPizza(pizzaId:number,pizsize: string ,quant :number)
        {
          // this.router.navigateByUrl("/pizzaorder/cost" ,{})
          console.log("*"+pizsize)
          console.log("*"+quant)
          this.router.navigateByUrl("/userpage/pizzaorder/cost", { state: { bookingOrderId:pizzaId , size:pizsize ,quantity :quant} });
        }

        //              <div *ngIf="pizzadata.pizzaSet">
        //             <div *ngFor="let pizza of pizzadata.pizzaSet">    
        //             <div> Pizza Id :{{pizzaOrders.pizza?.pizzaId}}</div>
        //             <div> Pizza Name:{{pizzaOrders.pizza?.pizzaName}}</div>
        //             <div> Pizza Type :{{pizzaOrders.pizza?.pizzaType}}</div>
        //             <div> Pizza Description :{{pizzaOrders.pizza?.pizzaDescription}}</div>
        //             <div> Pizza Cost :{{pizzaOrders.pizza?.pizzaCost}}</div>
        //             </div>
        //             </div>
   
}