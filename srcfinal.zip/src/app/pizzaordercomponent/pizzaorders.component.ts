import { Component } from '@angular/core';
import { observable, Observable } from 'rxjs';

import { PizzaOrderService } from '../service/pizzaorder.service';


@Component({
  selector: 'pizza-list',
    templateUrl: './pizzaorders.component.html',
 
})
export class PizzaOrderComponent 

{

}