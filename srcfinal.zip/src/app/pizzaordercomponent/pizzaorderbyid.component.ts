import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PizzaOrder } from '../model/pizzaorder.model';
import { PizzaService } from '../service/pizza.service';

import { PizzaOrderService } from '../service/pizzaorder.service';


@Component({
    selector: 'pizza-id',
    template: ` <div class="card-deck">
               <div class="col-md-5">
                <div class="container">
                 <br>
                <div style="card-align: center;">
                <div class="card" style="width: 20rem;">
                <div class="card-body">
                <div>
                  <div class=" py-3 my-3">
                    <div>BookingOrderId : {{pizzaOrders?.bookingOrderId}}</div>
                    <div>Transaction Mode : {{pizzaOrders?.transactionMode}}</div>
                    <div>Quantity : {{pizzaOrders?.quantity}}</div>
                    <div>Size : {{pizzaOrders?.size}}</div>
                    <div> 
                        Total Cost :{{pizzaOrders?.totalCost | currency: 'INR'}}
                    </div>
                    <div >Order Date : {{pizzaOrders?.orderDate | date}}
                    </div>
                    <div>
                    <div> Order Id :{{pizzaOrders?.order?.orderId}}</div>
                    <div> Order Type :{{pizzaOrders?.order?.orderType}}</div>
                    <div> Order Description :{{pizzaOrders?.order?.orderDescription}}</div>
                   <!-- <div> Order Customer Id :{{pizzaOrders?.order?.orderCustomerId}}</div> -->
                    </div>
                    <div *ngIf="pizzaOrders.pizzaSet">
                    <div *ngFor="let pizza of pizzaOrders.pizzaSet">
                    <div> Pizza Id :{{pizza?.pizzaId}}</div>
                    <div> Pizza Name:{{pizza?.pizzaName}}</div>
                    <div> Pizza Type :{{pizza?.pizzaType}}</div>
                    <div> Pizza Description :{{pizza?.pizzaDescription}}</div>
                     <div> Pizza Cost :{{pizza?.pizzaCost}}</div>
                     </div>
                     </div>
                    <div>
                    <button type="submit" class="btn btn-primary" (click) = "deletePizzaOrder(pizzaOrders?.bookingOrderId)">Delete</button>  &nbsp;&nbsp;
                    
                  </div>
                   <button type="submit" class="btn btn-primary" (click) = "updatePizza(pizzaOrders?.bookingOrderId)">Update</button>
                 &nbsp;&nbsp;
                 
                   <button type="submit" class="btn btn-primary" (click) = "totalCostOfPizza(pizzaOrders?.bookingOrderId,pizzaOrders?.size,pizzaOrders?.quantity)">Calculate</button>
                   
                  </div> 
                </div>

                `,
                styleUrls: ['./bookpizzaorder.component.css']


})
export class PizzaOrderByIdComponent {

  
  pizzaOrders: PizzaOrder;
  resError: string;
  

   
  constructor(private pizzaOrderService: PizzaOrderService, private activatedRoute: ActivatedRoute,private router :Router,private pizzaService :PizzaService) 
    {
      console.log("pizzaid in component"+activatedRoute.snapshot.params['pizzaId'])
        // this.pizzaOrders = this.pizzaService.getPizzaById(+activatedRoute.snapshot.params['pizzaId']);
         this.pizzaOrderService.getPizzaById(+activatedRoute.snapshot.params['pizzaId']).subscribe(
                                                                                          ( p )=>{this.pizzaOrders = p});
       
        }
        deletePizzaOrder(pizzaId : number){
          this.router.navigateByUrl("/userpage/pizzaorder/deleteorder/"+pizzaId)
        }
        updatePizza(pizzaId : number)
        {
          alert("Do you want to update the pizza")
          this.router.navigateByUrl("/userpage/pizzaorder/updatePizzaOrder/"+pizzaId)
        }

        totalCostOfPizza(pizzaId:number,pizsize: string ,quant :number)
        {
          // this.router.navigateByUrl("/pizzaorder/cost" ,{})
          console.log("*"+pizsize)
          console.log("*"+quant)
          this.router.navigateByUrl("/userpage/pizzaorder/cost", { state: { bookingOrderId:pizzaId , size:pizsize ,quantity :quant} });
        }

        //              <div *ngIf="pizzadata.pizzaSet">
        //             <div *ngFor="let pizza of pizzadata.pizzaSet">    
        //             <div> Pizza Id :{{pizzaOrders.pizza?.pizzaId}}</div>
        //             <div> Pizza Name:{{pizzaOrders.pizza?.pizzaName}}</div>
        //             <div> Pizza Type :{{pizzaOrders.pizza?.pizzaType}}</div>
        //             <div> Pizza Description :{{pizzaOrders.pizza?.pizzaDescription}}</div>
        //             <div> Pizza Cost :{{pizzaOrders.pizza?.pizzaCost}}</div>
        //             </div>
        //             </div>
   
}