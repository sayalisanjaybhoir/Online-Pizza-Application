import { Component } from "@angular/core";

@Component({

      template: `  
                
                <img src = "assets/images/error.jpg"/>
                <h1> 404 Page Not Found </h1>
                  `,
   
  })

export class Error404NotFound
{

}