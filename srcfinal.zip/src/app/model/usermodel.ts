export class UserModel{
     userId:number
    userName:string
    password:string


}