

export class Coupan{
 constructor(
  public  coupanId:number,
  public  coupanName:string,
  public coupanDescription:string,
  public  coupanDiscount:number,

  public imageUrl?:string,
    
  ) {}
}