export class AdminModel{
    
    adminId:number
    adminName:string
    password:string
   
   


}