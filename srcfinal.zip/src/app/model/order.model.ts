export class Order
{
   
     orderId: number
     orderType: string
     orderDescription: string
     orderCustomerId: number
    
    
}

// private int orderId;
// private String orderType;
// private String orderDescription;
// private int orderCustomerId;