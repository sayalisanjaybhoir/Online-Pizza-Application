

export class Customer{
constructor(
    public customerId : number,
    public customerName : string,
	public customerMobile : number,
	public customerEmail : string,
    public customerAddress : string,
    public userName : string,
    public password : string,
){}
}