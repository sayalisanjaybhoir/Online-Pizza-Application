export class Pizza {

    constructor(
   public pizzaId: number,
   public pizzaType:string,
  public  pizzaName: string,
  public  pizzaDescription:string,
  public  pizzaCost: number,
  public  minimumcost?: number,
  public  maximumcost?: number,
    ){}


}
    // constructor(
    //     public bookingOrderId: number,
    //     public orderDate: Date,
    //     public transactionMode:string,
    //     public quantity: number,
    //     public size: string,
    //     public totalCost: number,
    //     public order?:Order
    //      )
    



    // name: string
    // cost: number
    // ImageUrl?: string

