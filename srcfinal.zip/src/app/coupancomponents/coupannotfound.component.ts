import { Component } from '@angular/core';

@Component(
    {
        template:'<h1>ERROR 404 :This page doesnt exists</h1>',
        styles: ['h1 { font-weight: 700;   } '],
    }
)

export class Error404Component{
    
}
